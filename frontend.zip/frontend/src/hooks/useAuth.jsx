import { useState, useEffect } from 'react';
import api from '../services/api';

export default function useAuth() {
  const [user, setUser] = useState(null);

  const fetchMe = async () => {
    try {
      console.log('🔍 Fetching user data...');
      const res = await api.get('/users/me');
      console.log('🔍 User data received:', res.data);
      setUser(res.data.user);
    } catch (err) {
      console.error('🔴 Failed to fetch user:', err);
      setUser(null);
    }
  };

  useEffect(() => {
    fetchMe();
  }, []);

  return { user, fetchMe };
}