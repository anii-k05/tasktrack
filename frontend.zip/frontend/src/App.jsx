import { useEffect } from 'react';
import { Routes, Route, Navigate } from "react-router-dom";
import Login from "./pages/Login";
import Register from "./pages/Register"; 
import Dashboard from "./pages/Dashboard";
import Profile from "./pages/Profile"; 

const isAuthenticated = () => {
  const token = localStorage.getItem("token");
  return !!token;
};

export default function App() {
  useEffect(() => {
    document.title = "Tasktrack";
  }, []);

  return (
    <Routes>
      {}
      <Route path="/" element={<Navigate to="/login" />} />

      {}
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />

      {}
      <Route
        path="/dashboard"
        element={
          isAuthenticated() ? <Dashboard /> : <Navigate to="/login" replace />
        }
      />
      
      <Route
        path="/profile"
        element={
          isAuthenticated() ? <Profile /> : <Navigate to="/login" replace />
        }
      />

      {}
      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  );
}