import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import toast from "react-hot-toast";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  // Add this useEffect to check initial state
  useEffect(() => {
    console.log("🔍 Login component mounted");
    console.log("🔍 Current token in localStorage:", localStorage.getItem("token"));
    console.log("🔍 Current URL:", window.location.href);
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log("🔵 [1] Login form submitted"); // Debug 1
    
    if (!email || !password) {
      console.log("🔴 [2] Missing email or password"); // Debug 2
      return toast.error("Please fill all fields");
    }
    
    setLoading(true);
    try {
      console.log("🟡 [3] Making login API call to:", "http://localhost:4000/api/auth/login"); // Debug 3
      console.log("🟡 [4] Sending data:", { email, password }); // Debug 4
      
      const res = await axios.post("http://localhost:4000/api/auth/login", { 
        email, 
        password 
      });
      
      console.log("🟢 [5] Login API SUCCESS - Full response:", res); // Debug 5
      console.log("🟢 [6] Response data:", res.data); // Debug 6
      console.log("🟢 [7] Token received:", res.data.token); // Debug 7
      console.log("🟢 [8] Response status:", res.status); // Debug 8
      
      // Store the token
      console.log("🟡 [9] Storing token in localStorage..."); // Debug 9
      localStorage.setItem("token", res.data.token);
      
      // Verify token was stored
      const storedToken = localStorage.getItem("token");
      console.log("🟢 [10] Token verification - stored token:", storedToken); // Debug 10
      console.log("🟢 [11] Token length:", storedToken?.length); // Debug 11
      
      toast.success("Welcome back!");
      
      // Navigate to dashboard
      console.log("🟡 [12] Calling navigate('/dashboard')..."); // Debug 12
      navigate("/dashboard");
      console.log("🟢 [13] Navigate function completed without errors"); // Debug 13
      
      // Additional check after navigation
      setTimeout(() => {
        console.log("🟣 [14] Post-navigation check - Current URL:", window.location.href); // Debug 14
        console.log("🟣 [15] Post-navigation check - Token still in localStorage:", localStorage.getItem("token")); // Debug 15
      }, 100);
      
    } catch (error) {
      console.error("🔴 [ERROR] Login Failed:");
      console.error(" - Error message:", error.message);
      console.error(" - Response data:", error.response?.data);
      console.error(" - Response status:", error.response?.status);
      console.error(" - Full error:", error);
      
      toast.error(error.response?.data?.message || "Invalid credentials");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="h-screen w-screen bg-gradient-to-br from-stone-900 via-stone-800 to-amber-900 relative overflow-hidden">
      {/* Background that covers ENTIRE screen */}
      <div className="absolute inset-0 bg-gradient-to-br from-stone-900 via-stone-800 to-amber-900">
        {/* Large background elements covering ALL corners */}
        <div className="absolute -top-96 -left-96 w-[1500px] h-[1500px] bg-amber-500/10 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-96 -right-96 w-[1500px] h-[1500px] bg-stone-600/10 rounded-full blur-3xl"></div>
        <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-amber-400/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-[800px] h-[800px] bg-stone-500/5 rounded-full blur-3xl"></div>
      </div>

      {/* Content that spans FULL height */}
      <div className="relative h-full w-full flex">
        {/* Left Side - FULL HEIGHT Brand Section */}
        <div className="hidden lg:flex flex-1 flex-col justify-between p-16">
          {/* Top Logo */}
          <div className="flex items-center space-x-4">
            <div className="w-14 h-14 bg-gradient-to-br from-amber-400 to-amber-600 rounded-2xl flex items-center justify-center shadow-2xl">
              <span className="text-2xl font-bold text-stone-900">✓</span>
            </div>
            <span className="text-3xl font-bold text-amber-400">TaskTrack</span>
          </div>
          
          {/* Center Content */}
          <div className="max-w-2xl">
            <h1 className="text-6xl font-bold text-amber-100 mb-8 leading-tight">
              Streamline Your<br />Productivity
            </h1>
            <p className="text-amber-200/80 text-xl leading-relaxed">
              Organize, track, and complete your tasks efficiently with TaskTrack's 
              intuitive task management system designed for modern professionals.
            </p>
          </div>
          
          {/* Bottom Dots */}
          <div className="flex space-x-3">
            <div className="w-4 h-4 bg-amber-400 rounded-full"></div>
            <div className="w-4 h-4 bg-amber-400/50 rounded-full"></div>
            <div className="w-4 h-4 bg-amber-400/30 rounded-full"></div>
          </div>
        </div>

        {/* Right Side - FULL HEIGHT Form Section */}
        <div className="flex-1 flex items-center justify-center p-8">
          <div className="w-full max-w-md">
            {/* Mobile Header - Only shows on small screens */}
            <div className="lg:hidden flex justify-center mb-12">
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 bg-gradient-to-br from-amber-400 to-amber-600 rounded-2xl flex items-center justify-center shadow-2xl">
                  <span className="text-2xl font-bold text-stone-900">✓</span>
                </div>
                <span className="text-3xl font-bold text-amber-400">TaskTrack</span>
              </div>
            </div>

            {/* Login Form */}
            <div className="backdrop-blur-xl bg-stone-900/80 p-10 rounded-3xl shadow-2xl border border-amber-500/20">
              <div className="text-center mb-10">
                <h2 className="text-4xl font-bold text-amber-100 mb-3">
                  Welcome Back
                </h2>
                <p className="text-stone-400 text-lg">Sign in to your account</p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-8">
                <div className="space-y-6">
                  <div>
                    <label className="block text-stone-300 text-sm font-medium mb-3">
                      Email Address
                    </label>
                    <input
                      type="email"
                      placeholder="Enter your email"
                      className="w-full px-5 py-4 rounded-2xl bg-stone-800/50 border border-stone-600/50 focus:outline-none focus:ring-2 focus:ring-amber-500/50 focus:border-amber-500 text-stone-100 placeholder-stone-500 text-lg transition-all duration-300"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                    />
                  </div>
                  
                  <div>
                    <label className="block text-stone-300 text-sm font-medium mb-3">
                      Password
                    </label>
                    <input
                      type="password"
                      placeholder="Enter your password"
                      className="w-full px-5 py-4 rounded-2xl bg-stone-800/50 border border-stone-600/50 focus:outline-none focus:ring-2 focus:ring-amber-500/50 focus:border-amber-500 text-stone-100 placeholder-stone-500 text-lg transition-all duration-300"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className={`w-full py-4 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 rounded-2xl font-bold text-stone-900 text-lg shadow-2xl hover:shadow-amber-500/25 transition-all duration-300 ${
                    loading ? "opacity-50 cursor-not-allowed" : "hover:scale-105"
                  }`}
                >
                  {loading ? (
                    <div className="flex items-center justify-center space-x-3">
                      <div className="w-5 h-5 border-2 border-stone-900 border-t-transparent rounded-full animate-spin"></div>
                      <span>Logging in...</span>
                    </div>
                  ) : (
                    "Log In"
                  )}
                </button>
              </form>

              <div className="text-center mt-8 pt-8 border-t border-stone-700/50">
                <p className="text-stone-400">
                  Don't have an account?{" "}
                  <span
                    onClick={() => navigate("/register")}
                    className="text-amber-400 hover:text-amber-300 cursor-pointer font-bold hover:underline transition-colors duration-200"
                  >
                    Create one
                  </span>
                </p>
              </div>
            </div>

            {/* Mobile Footer */}
            <div className="lg:hidden text-center mt-12">
              <p className="text-stone-500">
                © 2024 TaskTrack. All rights reserved.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Desktop Footer */}
      <div className="hidden lg:block absolute bottom-8 left-16">
        <p className="text-stone-500">
          
        </p>
      </div>
    </div>
  );
}