import React, { useEffect, useState } from 'react';
import api from '../services/api';
import useAuth from '../hooks/useAuth';
import TaskForm from '../components/TaskForm';
import TaskList from '../components/TaskList';
import { useNavigate } from 'react-router-dom';

// Icons
const MenuIcon = () => <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" /></svg>;
const SearchIcon = () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>;
const BellIcon = () => <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-5 5v-5zM10.24 8.56a5.97 5.97 0 01-4.66-7.5 5.97 5.97 0 017.5 4.66 5.97 5.97 0 01-2.84 2.84z" /></svg>;
const CloseIcon = () => <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>;

export default function Dashboard() {
  const { user, fetchMe } = useAuth();
  const [tasks, setTasks] = useState([]);
  const [editing, setEditing] = useState(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const nav = useNavigate();

  // Filter tasks based on search
  const filteredTasks = tasks.filter(task =>
    task.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    task.description?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  async function loadTasks() {
    try {
      const res = await api.get('/tasks');
      setTasks(res.data.tasks || []);
    } catch (err) {
      console.error('Error loading tasks:', err);
      toast.error('Failed to load tasks');
    }
  }

  useEffect(() => { 
    loadTasks();
    fetchMe?.(); // Ensure user data is loaded
  }, []);

  async function handleSave(data) {
    try {
      if (editing) {
        await api.put(`/tasks/${editing.id}`, data);
        setEditing(null);
        toast.success('Task updated successfully!');
      } else {
        await api.post('/tasks', data);
        toast.success('Task created successfully!');
      }
      await loadTasks();
    } catch (err) {
      console.error('Error saving task:', err);
      toast.error('Failed to save task');
    }
  }

  async function handleDelete(id) {
    if (!confirm('Are you sure you want to delete this task?')) return;
    try {
      await api.delete(`/tasks/${id}`);
      toast.success('Task deleted successfully!');
      loadTasks();
    } catch (err) {
      console.error('Error deleting task:', err);
      toast.error('Failed to delete task');
    }
  }

  async function handleStatusChange(id, newStatus) {
    try {
      await api.put(`/tasks/${id}`, { status: newStatus });
      toast.success('Task status updated!');
      loadTasks();
    } catch (err) {
      console.error('Error updating task status:', err);
      toast.error('Failed to update task status');
    }
  }

  async function logout() {
    try {
      await api.post('/auth/logout');
      localStorage.removeItem('token');
      toast.success('Logged out successfully!');
      nav('/login');
    } catch (err) {
      console.error('Logout error:', err);
      localStorage.removeItem('token');
      nav('/login');
    }
  }

  // Stats calculation
  const taskStats = {
    total: tasks.length,
    completed: tasks.filter(t => t.status === 'completed').length,
    pending: tasks.filter(t => t.status === 'pending').length,
    inProgress: tasks.filter(t => t.status === 'inProgress').length,
  };

  return (
    <div className="h-screen w-screen bg-gradient-to-br from-stone-900 via-stone-800 to-amber-900 flex relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute -top-48 -left-48 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-48 -right-48 w-96 h-96 bg-stone-600/10 rounded-full blur-3xl"></div>
      </div>

      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div className={`
        fixed inset-y-0 left-0 z-50 w-80 bg-stone-900/95 backdrop-blur-xl border-r border-amber-500/20 
        transform transition-transform duration-300 ease-in-out
        ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} 
        lg:relative lg:translate-x-0 lg:z-auto
        flex-shrink-0
      `}>
        <div className="flex flex-col h-full">
          {/* Profile Section */}
          <div className="p-6 border-b border-amber-500/20">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-gradient-to-r from-amber-400 to-amber-600 rounded-2xl flex items-center justify-center text-stone-900 font-bold text-lg">
                {user?.name?.charAt(0)?.toUpperCase() || 'U'}
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-lg font-semibold text-amber-100 truncate">
                  {user?.name || 'User'}
                </h3>
                <p className="text-sm text-amber-200/70 truncate">{user?.email || ''}</p>
              </div>
              <button 
                onClick={() => setSidebarOpen(false)}
                className="lg:hidden p-2 hover:bg-stone-800 rounded-xl transition-colors"
              >
                <CloseIcon />
              </button>
            </div>
          </div>

          {/* Navigation */}
          <nav className="flex-1 p-6 space-y-2">
            <button 
              onClick={() => nav('/profile')}
              className="w-full flex items-center space-x-3 p-3 text-left rounded-xl hover:bg-gradient-to-r hover:from-amber-500/10 hover:to-amber-600/10 text-amber-100 hover:text-amber-300 transition-all duration-200"
            >
              <span className="font-medium">👤 Profile</span>
            </button>
            <button 
              onClick={() => nav('/settings')}
              className="w-full flex items-center space-x-3 p-3 text-left rounded-xl hover:bg-gradient-to-r hover:from-amber-500/10 hover:to-amber-600/10 text-amber-100 hover:text-amber-300 transition-all duration-200"
            >
              <span className="font-medium">⚙️ Settings</span>
            </button>
          </nav>

          {/* Quick Stats */}
          <div className="p-6 border-t border-amber-500/20">
            <div className="bg-gradient-to-r from-amber-500/10 to-amber-600/10 rounded-2xl p-4 border border-amber-500/20">
              <h4 className="font-semibold text-amber-100 mb-3">Quick Stats</h4>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="text-center p-2 bg-stone-800/50 rounded-lg">
                  <div className="font-bold text-amber-100">{taskStats.total}</div>
                  <div className="text-amber-200/70 text-xs">Total</div>
                </div>
                <div className="text-center p-2 bg-stone-800/50 rounded-lg">
                  <div className="font-bold text-green-400">{taskStats.completed}</div>
                  <div className="text-amber-200/70 text-xs">Done</div>
                </div>
                <div className="text-center p-2 bg-stone-800/50 rounded-lg">
                  <div className="font-bold text-orange-400">{taskStats.pending}</div>
                  <div className="text-amber-200/70 text-xs">Pending</div>
                </div>
                <div className="text-center p-2 bg-stone-800/50 rounded-lg">
                  <div className="font-bold text-blue-400">{taskStats.inProgress}</div>
                  <div className="text-amber-200/70 text-xs">In Progress</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Bar */}
        <header className="bg-stone-900/80 backdrop-blur-xl border-b border-amber-500/20 sticky top-0 z-30">
          <div className="flex items-center justify-between p-4">
            {/* Left Section */}
            <div className="flex items-center space-x-4">
              <button 
                onClick={() => setSidebarOpen(true)}
                className="lg:hidden p-2 hover:bg-stone-800 rounded-xl transition-colors"
              >
                <MenuIcon />
              </button>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-amber-400 to-amber-600 bg-clip-text text-transparent">
                Dashboard
              </h1>
            </div>

            {/* Search Bar */}
            <div className="flex-1 max-w-md mx-4">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <SearchIcon />
                </div>
                <input
                  type="text"
                  placeholder="Search tasks..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-stone-800/50 border-0 rounded-2xl focus:ring-2 focus:ring-amber-500/50 focus:bg-stone-800 text-amber-100 placeholder-amber-200/50 transition-all duration-200"
                />
              </div>
            </div>

            {/* Right Section */}
            <div className="flex items-center space-x-3">
              <button className="p-2.5 hover:bg-stone-800 rounded-2xl transition-colors relative">
                <BellIcon />
                <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full border-2 border-stone-900"></span>
              </button>
              <button 
                onClick={logout}
                className="px-4 py-2.5 bg-gradient-to-r from-red-500 to-orange-500 text-white rounded-2xl hover:shadow-lg transition-all duration-200 font-medium"
              >
                Logout
              </button>
            </div>
          </div>
        </header>

        {/* Main Content Area - Fixed scrolling issue */}
        <main className="flex-1 overflow-auto">
          <div className="p-6">
            {/* Welcome Card */}
            <div className="bg-gradient-to-r from-amber-500 to-amber-600 rounded-3xl p-8 text-stone-900 mb-8 shadow-2xl">
              <h2 className="text-3xl font-bold mb-2">
                Welcome back, {user?.name || 'User'}! 
              </h2>
              <p className="text-stone-800 text-lg font-medium">
                You have {taskStats.pending} pending tasks and {taskStats.completed} completed tasks.
              </p>
            </div>

            {/* Content Grid - Removed sticky positioning */}
            <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
              {/* Task Form Section - No longer sticky */}
              <div className="xl:col-span-1">
                <div className="bg-stone-900/80 backdrop-blur-xl rounded-3xl shadow-2xl border border-amber-500/20 p-6">
                  <h3 className="text-xl font-semibold text-amber-100 mb-6">
                    {editing ? ' Edit Task' : ' New Task'}
                  </h3>
                  <TaskForm 
                    initial={editing || {}} 
                    onSave={handleSave}
                    onCancel={() => setEditing(null)}
                  />
                </div>
              </div>

              {/* Task List Section */}
              <div className="xl:col-span-2">
                <div className="bg-stone-900/80 backdrop-blur-xl rounded-3xl shadow-2xl border border-amber-500/20 p-6">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-xl font-semibold text-amber-100"> Your Tasks</h3>
                    <div className="text-sm text-amber-200/70">
                      {filteredTasks.length} of {tasks.length} tasks
                    </div>
                  </div>
                  <TaskList 
                    tasks={filteredTasks} 
                    onEdit={setEditing}
                    onDelete={handleDelete}
                    onStatusChange={handleStatusChange}
                  />
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}