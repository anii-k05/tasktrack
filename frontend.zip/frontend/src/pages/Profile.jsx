import React, { useEffect, useState } from 'react';
import api from '../services/api';
import useAuth from '../hooks/useAuth';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';

export default function Profile() {
  const { user, fetchMe } = useAuth();
  const [form, setForm] = useState({ name: '', email: '' });
  const [loading, setLoading] = useState(false);
  const [changesMade, setChangesMade] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      setForm({ name: user.name || '', email: user.email || '' });
    }
  }, [user]);

  // Check if changes were made
  useEffect(() => {
    if (user) {
      const hasChanges = form.name !== user.name || form.email !== user.email;
      setChangesMade(hasChanges);
    }
  }, [form, user]);

  async function handleSave(e) {
    e.preventDefault();
    if (!changesMade) {
      toast.error('No changes to save');
      return;
    }

    setLoading(true);
    try {
      await api.put('/users/me', form);
      await fetchMe();
      toast.success('Profile updated successfully! 🎉');
      setChangesMade(false);
    } catch (err) {
      console.error('Profile update error:', err);
      toast.error(err?.response?.data?.message || 'Failed to update profile');
    } finally {
      setLoading(false);
    }
  }

  function handleCancel() {
    if (user) {
      setForm({ name: user.name, email: user.email });
      setChangesMade(false);
      toast.success('Changes discarded');
    }
  }

  if (!user) {
    return (
      <div className="h-screen w-screen flex items-center justify-center bg-gradient-to-br from-stone-900 via-stone-800 to-amber-900">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-amber-500 mx-auto mb-4"></div>
          <p className="text-amber-200">Loading profile...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen w-screen bg-gradient-to-br from-stone-900 via-stone-800 to-amber-900 relative overflow-auto">
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute -top-48 -left-48 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-48 -right-48 w-96 h-96 bg-stone-600/10 rounded-full blur-3xl"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-amber-400/5 rounded-full blur-2xl"></div>
      </div>

      <div className="relative z-10 py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <button 
              onClick={() => navigate('/dashboard')}
              className="inline-flex items-center text-sm text-amber-200/70 hover:text-amber-300 mb-6 transition-colors group"
            >
              <svg className="w-4 h-4 mr-2 group-hover:-translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
              </svg>
              Back to Dashboard
            </button>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-amber-400 to-amber-600 bg-clip-text text-transparent">
              Profile Settings
            </h1>
            <p className="text-amber-200/70 mt-2">Manage your account information and preferences</p>
          </div>

          {/* Profile Card */}
          <div className="bg-stone-900/80 backdrop-blur-xl rounded-3xl shadow-2xl border border-amber-500/20 overflow-hidden">
            {/* Profile Header */}
            <div className="bg-gradient-to-r from-amber-500 to-amber-600 p-6 text-stone-900">
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 bg-stone-900/20 rounded-2xl flex items-center justify-center text-amber-100 font-bold text-2xl backdrop-blur-sm border border-amber-500/30">
                  {user.name?.charAt(0)?.toUpperCase() || 'U'}
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-stone-900">{user.name}</h2>
                  <p className="text-stone-800 font-medium">{user.email}</p>
                </div>
              </div>
            </div>

            {/* Profile Form */}
            <div className="p-6">
              <form onSubmit={handleSave}>
                <div className="space-y-6">
                  {/* Name Field */}
                  <div>
                    <label className="block text-sm font-medium text-amber-100 mb-2">
                      Full Name
                    </label>
                    <input
                      type="text"
                      className="w-full px-4 py-3 bg-stone-800/50 border border-amber-500/20 rounded-2xl focus:ring-2 focus:ring-amber-500/50 focus:border-amber-500 text-amber-100 placeholder-amber-200/50 transition-all duration-200 outline-none"
                      value={form.name}
                      onChange={(e) => setForm({...form, name: e.target.value})}
                      placeholder="Enter your full name"
                    />
                  </div>

                  {/* Email Field */}
                  <div>
                    <label className="block text-sm font-medium text-amber-100 mb-2">
                      Email Address
                    </label>
                    <input
                      type="email"
                      className="w-full px-4 py-3 bg-stone-800/50 border border-amber-500/20 rounded-2xl focus:ring-2 focus:ring-amber-500/50 focus:border-amber-500 text-amber-100 placeholder-amber-200/50 transition-all duration-200 outline-none"
                      value={form.email}
                      onChange={(e) => setForm({...form, email: e.target.value})}
                      placeholder="Enter your email address"
                    />
                  </div>

                  {/* Account Info */}
                  <div className="bg-stone-800/50 rounded-2xl p-4 border border-amber-500/10">
                    <h3 className="font-medium text-amber-100 mb-2">Account Information</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-amber-200/70">Member since</span>
                        <p className="font-medium text-amber-100">
                          {user.createdAt ? new Date(user.createdAt).toLocaleDateString() : 'N/A'}
                        </p>
                      </div>
                      <div>
                        <span className="text-amber-200/70">User ID</span>
                        <p className="font-medium text-amber-100 truncate">{user.id}</p>
                      </div>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex flex-col sm:flex-row gap-3 pt-4">
                    <button
                      type="submit"
                      disabled={!changesMade || loading}
                      className={`flex-1 py-3 px-6 rounded-2xl font-medium transition-all duration-200 ${
                        changesMade && !loading
                          ? 'bg-gradient-to-r from-amber-500 to-amber-600 text-stone-900 hover:shadow-lg hover:shadow-amber-500/25 transform hover:scale-105'
                          : 'bg-stone-800 text-amber-200/40 cursor-not-allowed'
                      }`}
                    >
                      {loading ? (
                        <span className="flex items-center justify-center">
                          <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-stone-900" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                          Saving...
                        </span>
                      ) : (
                        'Save Changes'
                      )}
                    </button>
                    
                    <button
                      type="button"
                      onClick={handleCancel}
                      disabled={!changesMade}
                      className={`flex-1 py-3 px-6 border rounded-2xl font-medium transition-all duration-200 ${
                        changesMade
                          ? 'border-amber-500/30 text-amber-100 hover:bg-stone-800/50 hover:border-amber-500/50'
                          : 'border-amber-500/10 text-amber-200/40 cursor-not-allowed'
                      }`}
                    >
                      Discard Changes
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>

          {/* Additional Settings Section */}
          <div className="mt-6 bg-stone-900/80 backdrop-blur-xl rounded-3xl shadow-2xl border border-amber-500/20 p-6">
            <h3 className="text-lg font-semibold text-amber-100 mb-4">Account Actions</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <button 
                onClick={() => toast.success('Password reset feature coming soon!')}
                className="p-4 text-left border border-amber-500/20 rounded-2xl hover:border-amber-400 hover:bg-amber-500/10 transition-all duration-200 group"
              >
                <div className="text-amber-400 text-lg mb-1">🔒</div>
                <h4 className="font-medium text-amber-100 group-hover:text-amber-300">Reset Password</h4>
                <p className="text-sm text-amber-200/70 mt-1">Update your password for security</p>
              </button>
              
              <button 
                onClick={() => toast.error('Account deletion is not available yet')}
                className="p-4 text-left border border-amber-500/20 rounded-2xl hover:border-red-400 hover:bg-red-500/10 transition-all duration-200 group"
              >
                <div className="text-red-400 text-lg mb-1">🗑️</div>
                <h4 className="font-medium text-amber-100 group-hover:text-red-300">Delete Account</h4>
                <p className="text-sm text-amber-200/70 mt-1">Permanently remove your account</p>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}