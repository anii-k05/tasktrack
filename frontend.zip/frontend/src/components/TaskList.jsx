import React from 'react';

export default function TaskList({ tasks = [], onEdit, onDelete, onStatusChange }) {
  console.log('🔍 TaskList received tasks:', tasks);
  console.log('🔍 TaskList received onEdit:', onEdit);
  console.log('🔍 TaskList received onDelete:', onDelete);

  // Status badge configuration
  const getStatusConfig = (status) => {
    const configs = {
      todo: { label: 'To Do', color: 'bg-orange-100 text-orange-800', icon: '📝' },
      inProgress: { label: 'In Progress', color: 'bg-blue-100 text-blue-800', icon: '🔄' },
      completed: { label: 'Completed', color: 'bg-green-100 text-green-800', icon: '✅' }
    };
    return configs[status] || configs.todo;
  };

  const handleStatusChange = (taskId, newStatus) => {
    console.log('🔵 Status change requested:', taskId, newStatus);
    if (onStatusChange) {
      onStatusChange(taskId, newStatus);
    } else {
      console.error('❌ onStatusChange function not provided to TaskList');
    }
  };

  const handleEdit = (task) => {
    console.log('🔵 Edit button clicked for task:', task);
    if (onEdit) {
      onEdit(task);
    } else {
      console.error('❌ onEdit function not provided to TaskList');
    }
  };

  const handleDelete = (taskId) => {
    console.log('🔵 Delete button clicked for task ID:', taskId);
    if (onDelete) {
      onDelete(taskId);
    } else {
      console.error('❌ onDelete function not provided to TaskList');
    }
  };

  if (!tasks.length) {
    return (
      <div className="text-center py-12">
        <div className="text-6xl mb-4">📝</div>
        <h3 className="text-lg font-medium text-gray-700 mb-2">No tasks yet</h3>
        <p className="text-gray-500">Create your first task to get started!</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {tasks.map(task => {
        const statusConfig = getStatusConfig(task.status);
        
        return (
          <div key={task.id} className="bg-gray-50/80 border border-gray-200/60 rounded-2xl p-4 hover:shadow-sm transition-all duration-200 group">
            <div className="flex items-start justify-between">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-3 mb-2 flex-wrap">
                  <h4 className="font-semibold text-gray-800 truncate">
                    {task.title}
                  </h4>
                  <select
                    value={task.status}
                    onChange={(e) => handleStatusChange(task.id, e.target.value)}
                    className={`px-3 py-1 rounded-full text-xs font-medium ${statusConfig.color} border-0 focus:ring-2 focus:ring-teal-500/50 cursor-pointer transition-all duration-200`}
                  >
                    <option value="todo">📝 To Do</option>
                    <option value="inProgress">🔄 In Progress</option>
                    <option value="completed">✅ Completed</option>
                  </select>
                </div>
                
                {task.description && (
                  <p className="text-gray-600 text-sm mb-3 line-clamp-2">
                    {task.description}
                  </p>
                )}

                <div className="flex items-center gap-4 text-xs text-gray-500 flex-wrap">
                  {task.dueDate && (
                    <span className="flex items-center gap-1">
                      <span>📅</span>
                      {new Date(task.dueDate).toLocaleDateString()}
                    </span>
                  )}
                  <span className="flex items-center gap-1">
                    <span>🕐</span>
                    {task.createdAt ? new Date(task.createdAt).toLocaleDateString() : 'Just now'}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2 ml-4 opacity-70 group-hover:opacity-100 transition-opacity duration-200">
                <button
                  onClick={() => handleEdit(task)}
                  className="p-2 text-gray-400 hover:text-teal-600 hover:bg-teal-50 rounded-xl transition-all duration-200 hover:scale-110 active:scale-95"
                  title="Edit task"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                  </svg>
                </button>
                <button
                  onClick={() => handleDelete(task.id)}
                  className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all duration-200 hover:scale-110 active:scale-95"
                  title="Delete task"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                  </svg>
                </button>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}