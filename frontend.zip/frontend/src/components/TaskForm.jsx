import React, { useState, useEffect } from 'react';

export default function TaskForm({ initial = {}, onSave, onCancel }) {
  const [form, setForm] = useState({
    title: '',
    description: '',
    status: 'todo',
    dueDate: ''
  });

  useEffect(() => {
    console.log('🔄 TaskForm received initial:', initial);
    if (initial && initial.id) {
      setForm({
        title: initial.title || '',
        description: initial.description || '',
        status: initial.status || 'todo',
        dueDate: initial.dueDate || ''
      });
    } else {
      setForm({
        title: '',
        description: '',
        status: 'todo',
        dueDate: ''
      });
    }
  }, [initial]);

  function submit(e) {
    e.preventDefault();
    console.log('🔵 TaskForm submit triggered');
    console.log('🔵 Form data:', form);
    
    if (!form.title.trim()) {
      alert('Please enter a task title');
      return;
    }
    
    console.log('🟡 Calling onSave with:', form);
    onSave(form);
  }

  function handleCancel() {
    console.log('🔵 Cancel button clicked');
    setForm({
      title: '',
      description: '',
      status: 'todo',
      dueDate: ''
    });
    if (onCancel) onCancel();
  }

  const isEditing = initial && initial.id;

  return (
    <form onSubmit={submit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Task Title *
        </label>
        <input 
          required 
          className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-teal-500/50 focus:border-teal-500 transition-all duration-200 outline-none"
          placeholder="Enter task title" 
          value={form.title} 
          onChange={e => {
            console.log('📝 Title changing to:', e.target.value);
            setForm({...form, title: e.target.value})
          }}
        />
      </div>
      
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Description
        </label>
        <textarea 
          className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-teal-500/50 focus:border-teal-500 transition-all duration-200 outline-none resize-none"
          placeholder="Enter task description" 
          rows="3"
          value={form.description} 
          onChange={e => setForm({...form, description: e.target.value})}
        />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Status
          </label>
          <select 
            className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-teal-500/50 focus:border-teal-500 transition-all duration-200 outline-none"
            value={form.status} 
            onChange={e => setForm({...form, status: e.target.value})}
          >
            <option value="todo">📝 To Do</option>
            <option value="inProgress">🔄 In Progress</option>
            <option value="completed">✅ Completed</option>
          </select>
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Due Date
          </label>
          <input 
            type="date" 
            className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-teal-500/50 focus:border-teal-500 transition-all duration-200 outline-none"
            value={form.dueDate} 
            onChange={e => setForm({...form, dueDate: e.target.value})}
          />
        </div>
      </div>

      <div className="flex gap-3 pt-2">
        <button 
          type="submit"
          className="flex-1 py-3 bg-gradient-to-r from-teal-500 to-indigo-600 text-white rounded-2xl font-medium hover:shadow-lg transition-all duration-200 hover:scale-105 active:scale-95"
          onClick={() => console.log('🔵 Submit button clicked')}
        >
          {isEditing ? 'Update Task' : 'Create Task'}
        </button>
        
        {isEditing && (
          <button 
            type="button"
            onClick={handleCancel}
            className="px-6 py-3 border border-gray-300 text-gray-700 rounded-2xl font-medium hover:bg-gray-50 transition-all duration-200 hover:scale-105 active:scale-95"
          >
            Cancel
          </button>
        )}
      </div>
    </form>
  );
}